var searchData=
[
  ['setimagenocultar_0',['setImagenOcultar',['../classQuienEsQuien.html#ad44a90d52ce880db5b4b5dbdde58aefe',1,'QuienEsQuien']]],
  ['setmodograph_1',['setModoGraph',['../classQuienEsQuien.html#a9793d240139dbedccc66ef515c257c47',1,'QuienEsQuien']]],
  ['setprompt_2',['setPrompt',['../classConsola.html#a99c8860f927b534ca1a3c1a5c1b957d9',1,'Consola']]],
  ['setpulsadacasilla_3',['setPulsadaCasilla',['../classTableroGrafico.html#a48a32198438f7c8028027268a6a7fef6',1,'TableroGrafico']]],
  ['size_4',['size',['../classbintree.html#a38f4e4bcb0b8674d06eaea2d66506d64',1,'bintree']]]
];
