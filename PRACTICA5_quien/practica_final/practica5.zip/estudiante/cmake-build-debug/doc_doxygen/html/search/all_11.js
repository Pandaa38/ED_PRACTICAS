var searchData=
[
  ['tablero_5faleatorio_0',['tablero_aleatorio',['../classQuienEsQuien.html#ac0763b7ac0c24a3c54c2affaabe1f017',1,'QuienEsQuien']]],
  ['tablerografico_1',['tablerografico',['../classTableroGrafico.html',1,'TableroGrafico'],['../classTableroGrafico.html#a6f09621a58350c79f95a9be8f5e4cf6c',1,'TableroGrafico::TableroGrafico()']]],
  ['tda_20quienesquien_2',['¿Qué es el TDA QuienEsQuien?',['../index.html#autotoc_md0',1,'']]]
];
