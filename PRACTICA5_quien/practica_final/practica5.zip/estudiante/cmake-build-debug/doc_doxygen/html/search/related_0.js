var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classPregunta.html#a73ae888f02e362df0db841fadffd3dc8',1,'Pregunta::operator&lt;&lt;'],['../classQuienEsQuien.html#ad966941f935ffaf0940fc9a1343bf6c2',1,'QuienEsQuien::operator&lt;&lt;']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../classQuienEsQuien.html#a7a7a3baea184f3ce75f7df74327d5f8d',1,'QuienEsQuien']]]
];
