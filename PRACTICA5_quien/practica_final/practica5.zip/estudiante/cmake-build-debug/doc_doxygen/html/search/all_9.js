var searchData=
[
  ['la_20creación_20del_20árbol_20de_20preguntas_0',['Mejoras en la creación del árbol de preguntas',['../index.html#autotoc_md3',1,'']]],
  ['left_1',['left',['../classbintree_1_1node.html#a92d129216d418fe0cad3a7aaadf1d71e',1,'bintree::node']]],
  ['level_5fiterator_2',['level_iterator',['../classbintree_1_1level__iterator.html',1,'bintree']]],
  ['limpiar_3',['limpiar',['../classQuienEsQuien.html#a17703bc3277c2846fa67f857894366cd',1,'QuienEsQuien']]]
];
