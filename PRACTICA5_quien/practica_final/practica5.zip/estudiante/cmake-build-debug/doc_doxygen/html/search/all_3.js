var searchData=
[
  ['de_20preguntas_0',['Mejoras en la creación del árbol de preguntas',['../index.html#autotoc_md3',1,'']]],
  ['de_20quién_20es_20quién_1',['El Juego de Quién es Quién',['../index.html',1,'']]],
  ['del_20árbol_20de_20preguntas_2',['Mejoras en la creación del árbol de preguntas',['../index.html#autotoc_md3',1,'']]]
];
