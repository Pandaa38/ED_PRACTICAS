var searchData=
[
  ['¿qué_20es_20el_20tda_20quienesquien_0',['¿Qué es el TDA QuienEsQuien?',['../index.html#autotoc_md0',1,'']]]
];
