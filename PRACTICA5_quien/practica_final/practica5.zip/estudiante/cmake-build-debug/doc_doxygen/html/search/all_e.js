var searchData=
[
  ['quién_20es_20quién_0',['El Juego de Quién es Quién',['../index.html',1,'']]],
  ['quienesquien_1',['quienesquien',['../index.html#autotoc_md0',1,'¿Qué es el TDA QuienEsQuien?'],['../classQuienEsQuien.html',1,'QuienEsQuien'],['../classQuienEsQuien.html#a2942486f1ff134fec70e5d21d7916a2e',1,'QuienEsQuien::QuienEsQuien()'],['../classQuienEsQuien.html#a362b7513eba83170d18d98946bc01d87',1,'QuienEsQuien::QuienEsQuien(const QuienEsQuien &amp;quienEsQuien)']]],
  ['quienesquien_2eh_2',['quienesquien.h',['../quienesquien_8h.html',1,'']]]
];
