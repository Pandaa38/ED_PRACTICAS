var searchData=
[
  ['quienesquien_0',['quienesquien',['../classQuienEsQuien.html#a2942486f1ff134fec70e5d21d7916a2e',1,'QuienEsQuien::QuienEsQuien()'],['../classQuienEsQuien.html#a362b7513eba83170d18d98946bc01d87',1,'QuienEsQuien::QuienEsQuien(const QuienEsQuien &amp;quienEsQuien)']]]
];
