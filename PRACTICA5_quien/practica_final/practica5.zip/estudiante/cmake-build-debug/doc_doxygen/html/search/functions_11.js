var searchData=
[
  ['ventana_0',['Ventana',['../classVentana.html#a600937079ac72d1fb1ae58324136968f',1,'Ventana']]]
];
