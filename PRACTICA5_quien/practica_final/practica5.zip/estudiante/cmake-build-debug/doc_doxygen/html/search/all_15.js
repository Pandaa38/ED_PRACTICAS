var searchData=
[
  ['_7ebintree_0',['~bintree',['../classbintree.html#a7f32fcbdc9aed453025a13cbe93e3b89',1,'bintree']]],
  ['_7epregunta_1',['~Pregunta',['../classPregunta.html#a644894e8c4158aebd9e4ce443c59a0e4',1,'Pregunta']]],
  ['_7equienesquien_2',['~QuienEsQuien',['../classQuienEsQuien.html#ade80093df9e450c6e37e8992da112a70',1,'QuienEsQuien']]],
  ['_7etablerografico_3',['~TableroGrafico',['../classTableroGrafico.html#a7f41eebc706deb4c9cb2056c2a05b67d',1,'TableroGrafico']]]
];
