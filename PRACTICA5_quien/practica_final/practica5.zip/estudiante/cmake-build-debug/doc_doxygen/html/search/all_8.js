var searchData=
[
  ['keypressevent_0',['keyPressEvent',['../classConsola.html#aadabc7b5b906462eca8de2e7959048b2',1,'Consola']]]
];
