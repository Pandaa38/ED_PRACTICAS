var searchData=
[
  ['obtener_5fnum_5fpersonajes_0',['obtener_num_personajes',['../classPregunta.html#a15d67a0c5616ac05c6f18df9bbcdf0e8',1,'Pregunta']]],
  ['obtener_5fpersonaje_1',['obtener_personaje',['../classPregunta.html#aa0be8b318f02456b1d1512ac7f01bc54',1,'Pregunta']]],
  ['obtener_5fpregunta_2',['obtener_pregunta',['../classPregunta.html#a30cd02639654f2638ff5c813762f52eb',1,'Pregunta']]],
  ['ocultar_5fpersonajes_5fgraph_3',['ocultar_personajes_graph',['../classQuienEsQuien.html#a16918ae256aaea344a7d67e652bf5c63',1,'QuienEsQuien']]],
  ['operator_21_3d_4',['operator!=',['../classbintree.html#aea19f3886dbb4e7de1600da0e0d6d6ae',1,'bintree::operator!=()'],['../classbintree_1_1node.html#ae37e6a2934dfb46c4d0498ec6f441ce8',1,'bintree::node::operator!=(const node &amp;n) const']]],
  ['operator_2a_5',['operator*',['../classbintree_1_1node.html#ae3b25e1d16c449a3c0e211cd0ebe5739',1,'bintree::node::operator*()'],['../classbintree_1_1node.html#a8ded35c3a48209cc50dc82b699b470c8',1,'bintree::node::operator*() const']]],
  ['operator_3c_3c_6',['operator&lt;&lt;',['../classPregunta.html#a73ae888f02e362df0db841fadffd3dc8',1,'Pregunta::operator&lt;&lt;'],['../classQuienEsQuien.html#ad966941f935ffaf0940fc9a1343bf6c2',1,'QuienEsQuien::operator&lt;&lt;']]],
  ['operator_3d_7',['operator=',['../classbintree.html#a188622dd3846630d2f69b11a2eba3896',1,'bintree::operator=()'],['../classbintree_1_1node.html#a184f20617c0324caa3f66e4dce1338e5',1,'bintree::node::operator=()'],['../classPregunta.html#af41b87679d33b5a993d8cb6cb459fa0e',1,'Pregunta::operator=()'],['../classQuienEsQuien.html#a5c857869adbd07e3aa3ad727d04f18da',1,'QuienEsQuien::operator=()']]],
  ['operator_3d_3d_8',['operator==',['../classbintree.html#a512ebaa02cfd44fa4201745a5c8d64d1',1,'bintree::operator==()'],['../classbintree_1_1node.html#ae29b02f46d0708239bdeaba0b84f6f34',1,'bintree::node::operator==()']]],
  ['operator_3e_3e_9',['operator&gt;&gt;',['../classQuienEsQuien.html#a7a7a3baea184f3ce75f7df74327d5f8d',1,'QuienEsQuien']]]
];
