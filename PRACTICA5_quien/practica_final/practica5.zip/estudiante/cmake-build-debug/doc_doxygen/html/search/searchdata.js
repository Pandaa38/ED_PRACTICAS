var indexSectionsWithContent =
{
  0: "abcdegijklmnopqrstuvw~¿á",
  1: "bcilmnpqtv",
  2: "q",
  3: "abcegiklmnopqrstuvw~",
  4: "o",
  5: "dejq"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Friends",
  5: "Pages"
};

