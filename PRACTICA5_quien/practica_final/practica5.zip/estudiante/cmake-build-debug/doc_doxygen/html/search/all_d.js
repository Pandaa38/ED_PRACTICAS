var searchData=
[
  ['públicos_0',['Métodos Públicos',['../index.html#autotoc_md1',1,'']]],
  ['parent_1',['parent',['../classbintree_1_1node.html#a556268bd6133026def3213d133cee18d',1,'bintree::node']]],
  ['ponerenblanco_2',['PonerEnBlanco',['../classTableroGrafico.html#a7ec8d76b203297646e6c62ad9a91b1d0',1,'TableroGrafico']]],
  ['postorder_5fiterator_3',['postorder_iterator',['../classbintree_1_1postorder__iterator.html',1,'bintree']]],
  ['pregunta_4',['pregunta',['../classPregunta.html',1,'Pregunta'],['../classPregunta.html#aaac7bf3895f4b9259c870136a137b679',1,'Pregunta::Pregunta()'],['../classPregunta.html#a3f8660ca02e487029ab509fd85542d9b',1,'Pregunta::Pregunta(const Pregunta &amp;pregunta)'],['../classPregunta.html#a0d66edc0f1495dbddafcee131663e00c',1,'Pregunta::Pregunta(const string atributo, const int num_personajes)']]],
  ['preguntas_5',['Mejoras en la creación del árbol de preguntas',['../index.html#autotoc_md3',1,'']]],
  ['preguntas_5fformuladas_6',['preguntas_formuladas',['../classQuienEsQuien.html#adcb666b01429a92009d1991bb07379e1',1,'QuienEsQuien']]],
  ['preorder_5fiterator_7',['preorder_iterator',['../classbintree_1_1preorder__iterator.html',1,'bintree']]],
  ['privados_8',['Métodos Privados',['../index.html#autotoc_md2',1,'']]],
  ['profundidad_5fhojas_9',['profundidad_hojas',['../classQuienEsQuien.html#a2f2280a771c45b5f5367fda332f17caa',1,'QuienEsQuien']]],
  ['profundidad_5fpromedio_5fhojas_10',['profundidad_promedio_hojas',['../classQuienEsQuien.html#ae999ad6c20f9ebf6a710060b99741126',1,'QuienEsQuien']]],
  ['prompt_11',['prompt',['../classConsola.html#a06d0e6e23bd59d118fc83ac6ecdef77c',1,'Consola']]],
  ['prune_5fleft_12',['prune_left',['../classbintree.html#a74b4b7570b9b574391742f892520562b',1,'bintree']]],
  ['prune_5fright_13',['prune_right',['../classbintree.html#ae468b92dd3eb70818ffbd969ff34d811',1,'bintree']]],
  ['pulsacasilla_14',['pulsaCasilla',['../classTableroGrafico.html#a9bc0611cc00955a1ca922b7fb15235ea',1,'TableroGrafico']]],
  ['putimagen_15',['putImagen',['../classTableroGrafico.html#a33a16207544e84f564cee8d051ae3ba0',1,'TableroGrafico']]]
];
