var searchData=
[
  ['getcasilla_0',['getCasilla',['../classTableroGrafico.html#af72eae75fd534f14add32fe6fd79387c',1,'TableroGrafico']]],
  ['getcasillaelegida_1',['getCasillaElegida',['../classTableroGrafico.html#a50cc8556269085de74051c586acb973d',1,'TableroGrafico']]],
  ['getconsola_2',['getConsola',['../classVentana.html#a9b7e3020c22457c6d3f8249b2d5d4b16',1,'Ventana']]],
  ['getncols_3',['getNcols',['../classTableroGrafico.html#ad068ed620869203e21937c8135f5e1f5',1,'TableroGrafico']]],
  ['getnrows_4',['getNrows',['../classTableroGrafico.html#aa6e7beeff71005aad9a35c591b9aede9',1,'TableroGrafico']]],
  ['getpulsadacasilla_5',['getPulsadaCasilla',['../classTableroGrafico.html#a53c27713edce1520032e7275fab9b7b6',1,'TableroGrafico']]],
  ['gettablerografico_6',['getTableroGrafico',['../classVentana.html#ad05dbd102fb4455676f28e30e515339b',1,'Ventana']]]
];
