var searchData=
[
  ['tda_20maxqueue_0',['Representación del TDA MaxQueue',['../repMaxQueue.html',1,'']]],
  ['tda_20maxstack_1',['Representación del TDA MaxStack',['../repMaxStack.html',1,'']]],
  ['tda_20maxstack_20y_20maxqueue_2',['TDA MaxStack y MaxQueue',['../index.html',1,'']]]
];
