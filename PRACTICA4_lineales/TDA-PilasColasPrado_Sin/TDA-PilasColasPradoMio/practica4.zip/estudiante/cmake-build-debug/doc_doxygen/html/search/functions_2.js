var searchData=
[
  ['front_0',['front',['../classMaxQueue.html#ae28fd3d9d9c6842a2a62f41253387716',1,'MaxQueue']]]
];
