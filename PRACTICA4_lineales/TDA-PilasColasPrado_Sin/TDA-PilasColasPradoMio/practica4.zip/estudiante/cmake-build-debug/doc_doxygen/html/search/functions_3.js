var searchData=
[
  ['max_0',['max',['../classMaxQueue.html#a9958937d1f22e25246dcb0e3dbe13e30',1,'MaxQueue::max()'],['../classMaxStack.html#ad8345a2da5ad3b3ad4a9d85e8217f9cd',1,'MaxStack::max()']]],
  ['maxqueue_1',['MaxQueue',['../classMaxQueue.html#a55d1b81ef5b3ae41f00f3f46c241f066',1,'MaxQueue']]],
  ['maxstack_2',['MaxStack',['../classMaxStack.html#a1c547b5aa96407f62e7290dca83989d7',1,'MaxStack']]]
];
