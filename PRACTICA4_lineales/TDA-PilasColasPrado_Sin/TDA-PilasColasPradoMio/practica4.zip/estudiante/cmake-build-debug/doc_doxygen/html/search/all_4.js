var searchData=
[
  ['front_0',['front',['../classMaxQueue.html#ae28fd3d9d9c6842a2a62f41253387716',1,'MaxQueue']]],
  ['función_20de_20abstracción_1',['función de abstracción',['../repMaxQueue.html#faMaxQueue',1,'Función de abstracción'],['../repMaxStack.html#faMaxStack',1,'Función de abstracción']]]
];
