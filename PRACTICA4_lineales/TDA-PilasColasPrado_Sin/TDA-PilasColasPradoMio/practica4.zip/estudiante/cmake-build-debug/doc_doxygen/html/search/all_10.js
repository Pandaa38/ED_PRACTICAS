var searchData=
[
  ['¿qué_20es_20el_20tda_20maxqueue_0',['¿Qué es el TDA MaxQueue?',['../index.html#autotoc_md1',1,'']]],
  ['¿qué_20es_20el_20tda_20maxstack_1',['¿Qué es el TDA MaxStack?',['../index.html#autotoc_md0',1,'']]]
];
