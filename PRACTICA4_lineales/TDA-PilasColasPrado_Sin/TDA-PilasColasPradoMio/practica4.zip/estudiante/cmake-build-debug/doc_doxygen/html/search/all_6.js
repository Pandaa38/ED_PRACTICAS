var searchData=
[
  ['la_20representación_0',['la representación',['../repMaxQueue.html#invMaxQueue',1,'Invariante de la representación'],['../repMaxStack.html#invMaxStack',1,'Invariante de la representación']]]
];
