var searchData=
[
  ['abstracción_0',['abstracción',['../repMaxQueue.html#faMaxQueue',1,'Función de abstracción'],['../repMaxStack.html#faMaxStack',1,'Función de abstracción']]]
];
