var searchData=
[
  ['y_20maxqueue_0',['TDA MaxStack y MaxQueue',['../index.html',1,'']]]
];
