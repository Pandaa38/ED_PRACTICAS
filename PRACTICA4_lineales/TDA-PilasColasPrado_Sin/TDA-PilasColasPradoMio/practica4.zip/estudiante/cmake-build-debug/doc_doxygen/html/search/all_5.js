var searchData=
[
  ['invariante_20de_20la_20representación_0',['invariante de la representación',['../repMaxQueue.html#invMaxQueue',1,'Invariante de la representación'],['../repMaxStack.html#invMaxStack',1,'Invariante de la representación']]]
];
