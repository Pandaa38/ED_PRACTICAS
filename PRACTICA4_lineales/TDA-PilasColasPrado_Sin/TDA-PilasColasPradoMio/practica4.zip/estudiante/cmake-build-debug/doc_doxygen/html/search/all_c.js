var searchData=
[
  ['tda_20maxqueue_0',['tda maxqueue',['../index.html#autotoc_md1',1,'¿Qué es el TDA MaxQueue?'],['../repMaxQueue.html',1,'Representación del TDA MaxQueue']]],
  ['tda_20maxstack_1',['tda maxstack',['../index.html#autotoc_md0',1,'¿Qué es el TDA MaxStack?'],['../repMaxStack.html',1,'Representación del TDA MaxStack']]],
  ['tda_20maxstack_20y_20maxqueue_2',['TDA MaxStack y MaxQueue',['../index.html',1,'']]],
  ['top_3',['top',['../classMaxStack.html#ae6e9abea7dfbce13ebcba2a4f26df766',1,'MaxStack']]]
];
