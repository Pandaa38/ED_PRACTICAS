var searchData=
[
  ['maxqueue_0',['MaxQueue',['../classMaxQueue.html',1,'']]],
  ['maxstack_1',['MaxStack',['../classMaxStack.html',1,'']]]
];
