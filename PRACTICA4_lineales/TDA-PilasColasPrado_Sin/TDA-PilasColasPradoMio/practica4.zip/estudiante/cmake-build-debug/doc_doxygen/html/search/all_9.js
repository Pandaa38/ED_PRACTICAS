var searchData=
[
  ['pop_0',['pop',['../classMaxQueue.html#a7e03f10bfb0ccfe9471dc061b7659ef2',1,'MaxQueue::pop()'],['../classMaxStack.html#ab1498f141850cbf2ce83873fa0551747',1,'MaxStack::pop()']]],
  ['push_1',['push',['../classMaxQueue.html#a39862116a6223c2e460c9ad866c5531b',1,'MaxQueue::push()'],['../classMaxStack.html#ae1f9454e4ca00bbfa1038b1fbcd16931',1,'MaxStack::push()']]]
];
