var searchData=
[
  ['representación_0',['representación',['../repMaxQueue.html#invMaxQueue',1,'Invariante de la representación'],['../repMaxStack.html#invMaxStack',1,'Invariante de la representación']]],
  ['representación_20del_20tda_20maxqueue_1',['Representación del TDA MaxQueue',['../repMaxQueue.html',1,'']]],
  ['representación_20del_20tda_20maxstack_2',['Representación del TDA MaxStack',['../repMaxStack.html',1,'']]]
];
