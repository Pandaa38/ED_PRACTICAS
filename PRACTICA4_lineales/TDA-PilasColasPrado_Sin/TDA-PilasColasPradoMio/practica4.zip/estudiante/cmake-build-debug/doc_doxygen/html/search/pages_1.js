var searchData=
[
  ['maxqueue_0',['maxqueue',['../repMaxQueue.html',1,'Representación del TDA MaxQueue'],['../index.html',1,'TDA MaxStack y MaxQueue']]],
  ['maxstack_1',['Representación del TDA MaxStack',['../repMaxStack.html',1,'']]],
  ['maxstack_20y_20maxqueue_2',['TDA MaxStack y MaxQueue',['../index.html',1,'']]]
];
