var searchData=
[
  ['size_0',['size',['../classMaxQueue.html#aafcf61270934668051ae2577543c6416',1,'MaxQueue::size()'],['../classMaxStack.html#ab5793ca38a98af44e031002616b54af3',1,'MaxStack::size()']]]
];
