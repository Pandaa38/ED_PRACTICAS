var searchData=
[
  ['representación_20del_20tda_20maxqueue_0',['Representación del TDA MaxQueue',['../repMaxQueue.html',1,'']]],
  ['representación_20del_20tda_20maxstack_1',['Representación del TDA MaxStack',['../repMaxStack.html',1,'']]]
];
