var searchData=
[
  ['empty_0',['empty',['../classMaxQueue.html#a2b9c77f44485ecc0bb51b1234a9fee05',1,'MaxQueue::empty()'],['../classMaxStack.html#aba0884643ceeb60459d761d1124611bc',1,'MaxStack::empty()']]]
];
