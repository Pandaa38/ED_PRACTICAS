var searchData=
[
  ['tda_20imagen_0',['Representación del TDA Imagen .',['../repImagen.html',1,'']]],
  ['tda_20vídeo_1',['tda vídeo',['../index.html#autotoc_md1',1,'¿Qué es el TDA Vídeo?'],['../index.html',1,'TDA VÍDEO']]],
  ['tda_20video_2',['Representación del TDA Video .',['../repVideo.html',1,'']]]
];
