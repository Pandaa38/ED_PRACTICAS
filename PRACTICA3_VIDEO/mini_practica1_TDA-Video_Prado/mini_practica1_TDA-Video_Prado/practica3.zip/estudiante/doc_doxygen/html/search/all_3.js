var searchData=
[
  ['de_20abstracción_0',['de abstracción',['../repImagen.html#faImagen',1,'Función de abstracción'],['../repVideo.html#faVideo',1,'Función de abstracción']]],
  ['de_20la_20representación_1',['de la representación',['../repImagen.html#invImagen',1,'Invariante de la representación.'],['../repVideo.html#invVideo',1,'Invariante de la representación.']]],
  ['del_20tda_20imagen_2',['Representación del TDA Imagen .',['../repImagen.html',1,'']]],
  ['del_20tda_20video_3',['Representación del TDA Video .',['../repVideo.html',1,'']]]
];
