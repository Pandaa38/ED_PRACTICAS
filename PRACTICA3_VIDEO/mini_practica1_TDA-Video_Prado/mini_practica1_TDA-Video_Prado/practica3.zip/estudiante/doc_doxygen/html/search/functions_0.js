var searchData=
[
  ['adjustcontrast_0',['AdjustContrast',['../classImage.html#a4d51720b3d6a86990d6d597659dd4d68',1,'Image']]]
];
