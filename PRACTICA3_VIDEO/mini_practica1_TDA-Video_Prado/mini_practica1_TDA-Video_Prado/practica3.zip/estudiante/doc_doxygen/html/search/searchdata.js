var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstvwz~¿",
  1: "iv",
  2: "im",
  3: "abcegilmoprsvwz~",
  4: "p",
  5: "il",
  6: "nr",
  7: "dirtv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

