var searchData=
[
  ['image_0',['image',['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#a7aea4becfc078083ec9e366a5f5e4c92',1,'Image::Image(int nrows, int ncols, pixel value=0)'],['../classImage.html#a3df8303fb6d8b41ceb56ddf7be534cf9',1,'Image::Image(const char *file_path)'],['../classImage.html#abda271aa11b907dda8c8c8176684227d',1,'Image::Image(const Image &amp;orig)']]],
  ['insertar_1',['Insertar',['../classVideo.html#a130653995b45a8b870d1d4696978739d',1,'Video']]]
];
