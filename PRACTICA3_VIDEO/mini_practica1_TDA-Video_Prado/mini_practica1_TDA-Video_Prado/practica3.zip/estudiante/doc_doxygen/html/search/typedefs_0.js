var searchData=
[
  ['pixel_0',['pixel',['../image_8h.html#a75b4a8d321f28469ec157cd62505d6a6',1,'image.h']]]
];
