var searchData=
[
  ['readimagekind_0',['readimagekind',['../imageIO_8h.html#aae1362cc5bced97d9e2c15aaa8ce313d',1,'ReadImageKind(const char *path):&#160;imageIO.cpp'],['../imageIO_8cpp.html#a6dea11974ea8c8c101628f3505960a39',1,'ReadImageKind(const char *nombre):&#160;imageIO.cpp']]],
  ['reading_5ferror_1',['READING_ERROR',['../image_8h.html#abf07f72999ea5b856ced9c5fe0a64f70a17bcf9ac986e66b6a333261c119606ca',1,'image.h']]],
  ['readpgmimage_2',['readpgmimage',['../imageIO_8h.html#a525d6596843ac8e425495cdc6717b747',1,'ReadPGMImage(const char *path, int &amp;rows, int &amp;cols):&#160;imageIO.cpp'],['../imageIO_8cpp.html#a525d6596843ac8e425495cdc6717b747',1,'ReadPGMImage(const char *path, int &amp;rows, int &amp;cols):&#160;imageIO.cpp']]],
  ['rebobinar_3a_3',['Rebobinar:',['../index.html#autotoc_md3',1,'']]],
  ['representación_4',['representación',['../repImagen.html#invImagen',1,'Invariante de la representación.'],['../repVideo.html#invVideo',1,'Invariante de la representación.']]],
  ['representación_20del_20tda_20imagen_5',['Representación del TDA Imagen .',['../repImagen.html',1,'']]],
  ['representación_20del_20tda_20video_6',['Representación del TDA Video .',['../repVideo.html',1,'']]]
];
