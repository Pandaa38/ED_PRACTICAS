var searchData=
[
  ['¿qué_20es_20el_20tda_20vídeo_0',['¿Qué es el TDA Vídeo?',['../index.html#autotoc_md1',1,'']]],
  ['¿qué_20se_20entiende_20por_20imagen_1',['¿Qué se entiende por imagen?',['../index.html#autotoc_md0',1,'']]]
];
