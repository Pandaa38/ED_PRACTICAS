var searchData=
[
  ['imagen_0',['Representación del TDA Imagen .',['../repImagen.html',1,'']]]
];
