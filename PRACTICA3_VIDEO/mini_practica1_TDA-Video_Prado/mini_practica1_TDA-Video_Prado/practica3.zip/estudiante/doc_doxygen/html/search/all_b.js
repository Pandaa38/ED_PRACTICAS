var searchData=
[
  ['operator_2a_0',['operator*',['../classImage.html#a073626b8ed10e5aede4f4b8f22c7a684',1,'Image']]],
  ['operator_2b_1',['operator+',['../classImage.html#a9593fa0b9bdde26486b48435736b6a8c',1,'Image']]],
  ['operator_3d_2',['operator=',['../classImage.html#aeaa2d687caf48e3c72fc773c70a0e9fa',1,'Image::operator=()'],['../classVideo.html#aa27adeb5ff6294f2c1cfbf2d69d3b8e3',1,'Video::operator=(const Video &amp;V)']]],
  ['operator_5b_5d_3',['operator[]',['../classVideo.html#a8e733b1756567f4a94e69e6548dcc625',1,'Video::operator[](int foto)'],['../classVideo.html#a1f88dcbeaba4949a1f98da0af7b5314b',1,'Video::operator[](int foto) const']]]
];
