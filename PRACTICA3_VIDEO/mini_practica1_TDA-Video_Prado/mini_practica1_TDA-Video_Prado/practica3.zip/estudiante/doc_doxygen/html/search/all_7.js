var searchData=
[
  ['image_0',['image',['../classImage.html',1,'Image'],['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#a7aea4becfc078083ec9e366a5f5e4c92',1,'Image::Image(int nrows, int ncols, pixel value=0)'],['../classImage.html#a3df8303fb6d8b41ceb56ddf7be534cf9',1,'Image::Image(const char *file_path)'],['../classImage.html#abda271aa11b907dda8c8c8176684227d',1,'Image::Image(const Image &amp;orig)']]],
  ['image_2ecpp_1',['image.cpp',['../image_8cpp.html',1,'']]],
  ['image_2eh_2',['image.h',['../image_8h.html',1,'']]],
  ['imageio_2ecpp_3',['imageIO.cpp',['../imageIO_8cpp.html',1,'']]],
  ['imageio_2eh_4',['imageIO.h',['../imageIO_8h.html',1,'']]],
  ['imagekind_5',['ImageKind',['../imageIO_8h.html#a18b6324755c82f3edc3da0a37066dc53',1,'imageIO.h']]],
  ['imagen_6',['imagen',['../index.html#autotoc_md0',1,'¿Qué se entiende por imagen?'],['../repImagen.html',1,'Representación del TDA Imagen .']]],
  ['insertar_7',['Insertar',['../classVideo.html#a130653995b45a8b870d1d4696978739d',1,'Video']]],
  ['invariante_20de_20la_20representación_8',['invariante de la representación',['../repImagen.html#invImagen',1,'Invariante de la representación.'],['../repVideo.html#invVideo',1,'Invariante de la representación.']]]
];
