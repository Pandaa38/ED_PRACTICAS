var searchData=
[
  ['título_20de_20la_20página_20principal_0',['Título de la página principal',['../index.html',1,'']]],
  ['tda_20imagen_1',['Representación del TDA Imagen .',['../repImagen.html',1,'']]],
  ['tda_20video_2',['Representación del TDA Video .',['../repVideo.html',1,'']]]
];
