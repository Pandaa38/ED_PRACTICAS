var searchData=
[
  ['borrar_0',['Borrar',['../classVideo.html#a7b875a8f5f2c05f58e0bba19d191f252',1,'Video']]]
];
