var searchData=
[
  ['video_0',['video',['../classVideo.html#ab67336c2c5b6227a9635bc7dcd6af543',1,'Video::Video()'],['../classVideo.html#a619b95a343ae877b37fb98d46e144fbe',1,'Video::Video(int n)'],['../classVideo.html#a95f8f9ba9998af7e692733b1d5adeee8',1,'Video::Video(const Video &amp;V)']]]
];
