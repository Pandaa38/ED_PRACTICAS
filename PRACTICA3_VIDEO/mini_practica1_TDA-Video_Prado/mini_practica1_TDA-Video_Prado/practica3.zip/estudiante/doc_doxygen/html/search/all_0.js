var searchData=
[
  ['abstracción_0',['abstracción',['../repImagen.html#faImagen',1,'Función de abstracción'],['../repVideo.html#faVideo',1,'Función de abstracción']]],
  ['adjustcontrast_1',['AdjustContrast',['../classImage.html#a4d51720b3d6a86990d6d597659dd4d68',1,'Image']]]
];
