var searchData=
[
  ['empty_0',['Empty',['../classImage.html#a0866c8c2e288fd753168a9c691ae17d2',1,'Image']]],
  ['escribirvideo_1',['EscribirVideo',['../classVideo.html#a9d857398df3edb149ebeaff7926316a8',1,'Video']]]
];
