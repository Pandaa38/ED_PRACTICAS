var searchData=
[
  ['representación_20del_20tda_20imagen_0',['Representación del TDA Imagen .',['../repImagen.html',1,'']]],
  ['representación_20del_20tda_20video_1',['Representación del TDA Video .',['../repVideo.html',1,'']]]
];
