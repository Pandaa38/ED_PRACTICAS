var searchData=
[
  ['la_20representación_0',['la representación',['../repImagen.html#invImagen',1,'Invariante de la representación.'],['../repVideo.html#invVideo',1,'Invariante de la representación.']]],
  ['leervideo_1',['LeerVideo',['../classVideo.html#a5db092ed4780237434628a19387b3d09',1,'Video']]],
  ['load_2',['Load',['../classImage.html#a997e2d58be54bca2cf8f4da5818bf771',1,'Image']]],
  ['loadresult_3',['LoadResult',['../image_8h.html#abf07f72999ea5b856ced9c5fe0a64f70',1,'image.h']]]
];
