var searchData=
[
  ['reading_5ferror_0',['READING_ERROR',['../image_8h.html#abf07f72999ea5b856ced9c5fe0a64f70a17bcf9ac986e66b6a333261c119606ca',1,'image.h']]]
];
