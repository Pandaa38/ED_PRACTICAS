var searchData=
[
  ['get_5fcols_0',['get_cols',['../classImage.html#ac52444a5ffbbc50d6dde8375ca5f45ea',1,'Image']]],
  ['get_5fpixel_1',['get_pixel',['../classImage.html#a04f8c23183c8f9a2abcdd11ff7056d53',1,'Image::get_pixel(int i, int j) const'],['../classImage.html#a3e25868ec6d71a56017f8693c8d21a90',1,'Image::get_pixel(int k) const']]],
  ['get_5frows_2',['get_rows',['../classImage.html#a19fc606085e6e76dedf57b7de391dfdb',1,'Image']]]
];
