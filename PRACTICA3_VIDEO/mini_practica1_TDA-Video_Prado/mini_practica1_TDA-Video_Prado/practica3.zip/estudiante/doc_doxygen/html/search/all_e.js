var searchData=
[
  ['save_0',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['se_20entiende_20por_20imagen_1',['¿Qué se entiende por imagen?',['../index.html#autotoc_md0',1,'']]],
  ['set_5fpixel_2',['set_pixel',['../classImage.html#a23f5eb99cdca65602c13c84821686abd',1,'Image::set_pixel(int i, int j, pixel value)'],['../classImage.html#ae44db8ef6cc1a243c9d0e2c42bc0a78b',1,'Image::set_pixel(int k, pixel value)']]],
  ['showenglishhelp_3',['showEnglishHelp',['../morphing_8cpp.html#a82208e7f47d4a50db15e00036cfdf73a',1,'morphing.cpp']]],
  ['size_4',['size',['../classVideo.html#a0fb9db4274bc166d394880b96d0cbef5',1,'Video']]],
  ['subsample_5',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
