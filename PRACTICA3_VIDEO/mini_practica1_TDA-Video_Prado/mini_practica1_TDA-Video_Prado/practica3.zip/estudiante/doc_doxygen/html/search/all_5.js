var searchData=
[
  ['función_20de_20abstracción_0',['función de abstracción',['../repImagen.html#faImagen',1,'Función de abstracción'],['../repVideo.html#faVideo',1,'Función de abstracción']]]
];
