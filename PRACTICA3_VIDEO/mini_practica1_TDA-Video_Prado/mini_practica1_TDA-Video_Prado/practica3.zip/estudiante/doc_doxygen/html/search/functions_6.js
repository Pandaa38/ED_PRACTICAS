var searchData=
[
  ['leervideo_0',['LeerVideo',['../classVideo.html#a5db092ed4780237434628a19387b3d09',1,'Video']]],
  ['load_1',['Load',['../classImage.html#a997e2d58be54bca2cf8f4da5818bf771',1,'Image']]]
];
