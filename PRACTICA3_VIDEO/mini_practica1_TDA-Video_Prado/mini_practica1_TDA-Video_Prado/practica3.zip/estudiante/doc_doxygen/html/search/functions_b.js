var searchData=
[
  ['save_0',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['set_5fpixel_1',['set_pixel',['../classImage.html#a23f5eb99cdca65602c13c84821686abd',1,'Image::set_pixel(int i, int j, pixel value)'],['../classImage.html#ae44db8ef6cc1a243c9d0e2c42bc0a78b',1,'Image::set_pixel(int k, pixel value)']]],
  ['showenglishhelp_2',['showEnglishHelp',['../morphing_8cpp.html#a82208e7f47d4a50db15e00036cfdf73a',1,'morphing.cpp']]],
  ['size_3',['size',['../classVideo.html#a0fb9db4274bc166d394880b96d0cbef5',1,'Video']]],
  ['subsample_4',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
