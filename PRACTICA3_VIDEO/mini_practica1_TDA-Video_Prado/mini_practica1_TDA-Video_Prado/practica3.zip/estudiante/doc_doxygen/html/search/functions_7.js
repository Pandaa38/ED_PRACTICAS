var searchData=
[
  ['mean_0',['Mean',['../classImage.html#a08ac7df75c7bc99da2b3abdc35719203',1,'Image']]],
  ['morphing_1',['Morphing',['../morphing_8cpp.html#a29a6a86ade554f6d92565250c67e5d95',1,'morphing.cpp']]]
];
