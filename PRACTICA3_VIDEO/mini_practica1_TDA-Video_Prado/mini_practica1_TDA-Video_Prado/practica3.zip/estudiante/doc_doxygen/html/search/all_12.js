var searchData=
[
  ['zoom2x_0',['Zoom2X',['../classImage.html#af7c220a99f8b90c6e9f243ee22943305',1,'Image']]]
];
