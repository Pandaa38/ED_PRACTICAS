var searchData=
[
  ['paintin_0',['PaintIn',['../classImage.html#ab56274cc499c308d53a6b2c4830e4fac',1,'Image']]],
  ['pixel_1',['pixel',['../image_8h.html#a75b4a8d321f28469ec157cd62505d6a6',1,'image.h']]],
  ['por_20imagen_2',['¿Qué se entiende por imagen?',['../index.html#autotoc_md0',1,'']]]
];
